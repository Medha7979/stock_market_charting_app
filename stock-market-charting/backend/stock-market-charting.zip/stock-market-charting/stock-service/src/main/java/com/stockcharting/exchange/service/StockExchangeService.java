package com.stockcharting.exchange.service;

import java.util.Optional;

import com.stockcharting.exchange.entity.StockExchange;


public interface StockExchangeService {
	
	Iterable<StockExchange> getAllStockExchanges();

	Optional<StockExchange> getByStockExchangeName(String stockExchangeName);

	Optional<StockExchange> getByStockExchangeId(int id);

	Optional<StockExchange> insertUpdate(StockExchange stockExchange);
}

package com.stockcharting.repos;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stockcharting.entities.Stock;

@Repository
public interface StockRepos extends JpaRepository<Stock, Integer> {

	Optional<Stock> findFirstByCompanyCodeOrderByStockDateTimeDesc(String companyCode);

	Iterable<Stock> findAllByOrderByStockDateTimeAsc();

	Iterable<Stock> findAllByCompanyCodeOrderByStockDateTimeAsc(String companyCode);

	Iterable<Stock> findAllByStockDateTimeBetween(LocalDateTime start, LocalDateTime end);

	Iterable<Stock> findAllByCompanyCodeAndStockDateTimeBetween(String companyCode, LocalDateTime start,
			LocalDateTime end);

	Iterable<Stock> findAllByCompanyCodeInOrderByStockDateTimeAsc(List<String> companyCodeList);

	Iterable<Stock> findAllByCompanyCodeInAndStockDateTimeBetween(List<String> companyCodeList, LocalDateTime start,
			LocalDateTime end);
	
	Optional<Stock> findByCompanyCodeAndStockExchangeCodeAndStockDateTime(String stockCode, String exchange, LocalDateTime ldt);

}

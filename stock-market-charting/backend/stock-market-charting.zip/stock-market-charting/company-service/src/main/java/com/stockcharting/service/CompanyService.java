package com.stockcharting.service;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockcharting.entities.Company;

public interface CompanyService {

	Optional<Company> getCompanyById(int id);

	Optional<Company> getCompanyByCompanyName(String companyName);

	Optional<Company> getCompanyByCompanyCode(String companyCode);

	Iterable<Company> getAll();

	Iterable<Company> getAllBySectorName(String sectorName);

	Iterable<Company> getAllByStockExchange(String stockExchange);

	Iterable<Company> getAllByCompanyNameContaining(String companyName);

	Iterable<Company> getAllByCompanyCodeContaining(String companyCode);

	Optional<Company> insertUpdateCompany(Company company);
	
	Optional<Company> setCompanyStatus(String companyName, String active);
}

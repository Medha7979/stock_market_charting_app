package com.stockcharting.service;

import java.util.Optional;

import com.stockcharting.entities.IPODetails;

public interface IpoService {
	
	Optional<IPODetails> getIpoDetailsByCompanyName(String companyName);

	Iterable<IPODetails> getAllOrderByOpenDateTimeAsc();

	Optional<IPODetails> insertUpdateIpoDetails(IPODetails ipoDetails);


}

package com.stockcharting.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.stockcharting.entities.IPODetails;
import com.stockcharting.exception.ResourceNotFoundException;
import com.stockcharting.dto.IPODtls;
import com.stockcharting.service.IpoService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/ipo")
public class IpoController {

	@Autowired
	IpoService ipoService;

	@RequestMapping(value = "/name/{companyName}", method = RequestMethod.GET)
	public ResponseEntity<IPODtls> getIpoByName(@PathVariable("companyName") String companyName) {
		Optional<IPODetails> ipoDetails = ipoService.getIpoDetailsByCompanyName(companyName);
		IPODtls ipoDtls = convertToDto(ipoDetails.orElseThrow(() -> new ResourceNotFoundException("No IPO For this company")));
		return ResponseEntity.status(HttpStatus.FOUND).body(ipoDtls);
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public ResponseEntity<List<IPODtls>> getAllIpo() {
		Iterable<IPODetails> ipoList = ipoService.getAllOrderByOpenDateTimeAsc();
		List<IPODtls> ipoDtlsList = new ArrayList<IPODtls>();
		for (IPODetails i : ipoList) {
			ipoDtlsList.add(convertToDto(i));
		}
		return ResponseEntity.status(HttpStatus.OK).body(ipoDtlsList);
	}

	@RequestMapping(value = "/new", method = RequestMethod.POST)
	public ResponseEntity<IPODtls> addNewIpo(@RequestBody IPODtls ipoDtls) {
		IPODetails ipoDetails = (new ModelMapper()).map(ipoDtls, IPODetails.class);
		Optional<IPODetails> ipo = ipoService.insertUpdateIpoDetails(ipoDetails);
		ipoDtls = convertToDto(ipo.get());
		return ResponseEntity.status(HttpStatus.CREATED).body(ipoDtls);
	}

	@RequestMapping(value = "/update/{companyName}", method = RequestMethod.PUT)
	public ResponseEntity<IPODtls> updateIpo(@PathVariable("companyName") String companyName,
			@RequestBody IPODtls ipoDtls) {
		IPODetails ipoDetails = ipoService.getIpoDetailsByCompanyName(companyName)
				.orElseThrow(() -> new ResourceNotFoundException("No IPO for this company"));
		ipoDetails = (new ModelMapper()).map(ipoDtls, IPODetails.class);
		ipoDtls = convertToDto(ipoService.insertUpdateIpoDetails(ipoDetails).get());
		return ResponseEntity.status(HttpStatus.CREATED).body(ipoDtls);
	}

	private IPODtls convertToDto(IPODetails ipoDetails) {
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		IPODtls ipoDtls = modelMapper.map(ipoDetails, IPODtls.class);
		return ipoDtls;

	}
}

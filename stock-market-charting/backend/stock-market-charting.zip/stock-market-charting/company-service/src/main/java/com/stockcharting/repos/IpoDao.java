package com.stockcharting.repos;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stockcharting.entities.IPODetails;

@Repository
public interface IpoDao extends JpaRepository<IPODetails, Integer> {

	Optional<IPODetails> findByCompanyName(String companyName);

	Iterable<IPODetails> findAllByOrderByOpenDateTimeAsc();
}

package com.stockcharting.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.stockcharting.repos.CompanyRepos;
import com.stockcharting.entities.Company;

@Service
@EnableTransactionManagement
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyRepos CompanyRepos;

	@Override
	@Transactional
	public Optional<Company> getCompanyById(int id) {

		return CompanyRepos.findById(id);
	}

	@Override
	@Transactional
	public Optional<Company> getCompanyByCompanyName(String companyName) {

		return CompanyRepos.findByCompanyName(companyName);
	}

	@Override
	@Transactional
	public Optional<Company> getCompanyByCompanyCode(String companyCode) {

		return CompanyRepos.findByCompanyCode(companyCode);
	}

	@Override
	@Transactional
	public Iterable<Company> getAll() {

		return CompanyRepos.findAll();
	}

	@Override
	@Transactional
	public Iterable<Company> getAllBySectorName(String sectorName) {

		return CompanyRepos.findAllBySectorName(sectorName);
	}

	@Override
	@Transactional
	public Iterable<Company> getAllByStockExchange(String stockExchange) {

		return CompanyRepos.findAllByStockExchange(stockExchange);
	}

	@Override
	@Transactional
	public Iterable<Company> getAllByCompanyNameContaining(String companyName) {

		return CompanyRepos.findAllByCompanyNameContaining(companyName);
	}

	@Override
	@Transactional
	public Iterable<Company> getAllByCompanyCodeContaining(String companyCode) {

		return CompanyRepos.findAllByCompanyCodeContaining(companyCode);
	}

	@Override
	@Transactional
	public Optional<Company> insertUpdateCompany(Company company) {
		CompanyRepos.save(company);
		return Optional.of(company);
	}
	
	@Override
	@Transactional
	public Optional<Company> setCompanyStatus(String companyName, String active){
		return CompanyRepos.setCompanyStatus(companyName, active);
	}

}

package com.stockcharting.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.stockcharting.repos.StockRepos;
import com.stockcharting.entities.Stock;

@Service
@EnableTransactionManagement
public class StockServiceImpl implements StockService {
	
	@Autowired
	StockRepos StockRepos;
	
	@Override
	@Transactional
	public Optional<Stock> getFirstByCompanyCodeOrderByStockDateTimeDesc(String companyCode) {
		
		return StockRepos.findFirstByCompanyCodeOrderByStockDateTimeDesc(companyCode);
	}

	@Override
	@Transactional
	public Iterable<Stock> getAll() {
		
		return StockRepos.findAllByOrderByStockDateTimeAsc();
	}

	@Override
	@Transactional
	public Iterable<Stock> getAllByCompany(String companyCode) {
		
		return StockRepos.findAllByCompanyCodeOrderByStockDateTimeAsc(companyCode);
	}

	@Override
	@Transactional
	public Iterable<Stock> getAllByStockDateTimeBetween(LocalDateTime start, LocalDateTime end) {
		
		return StockRepos.findAllByStockDateTimeBetween(start, end);
	}

	@Override
	@Transactional
	public Iterable<Stock> getAllByCompanyCodeAndStockDateTimeBetween(String companyCode, LocalDateTime start,
			LocalDateTime end) {
		
		return StockRepos.findAllByCompanyCodeAndStockDateTimeBetween(companyCode, start, end);
	}

	@Override
	@Transactional
	public Iterable<Stock> getAllByCompanyCodeIn(List<String> companyCodeList) {
		
		return StockRepos.findAllByCompanyCodeInOrderByStockDateTimeAsc(companyCodeList);
	}

	@Override
	@Transactional
	public Iterable<Stock> getAllByCompanyCodeInAndStockDateTimeBetween(List<String> companyCodeList, LocalDateTime start,
			LocalDateTime end) {
		
		return StockRepos.findAllByCompanyCodeInAndStockDateTimeBetween(companyCodeList, start, end);
	}
	
	@Override
	@Transactional
	public Optional<Stock> insertUpdateStock(Stock stock){
		return Optional.of(StockRepos.save(stock));
	}
	
	@Override
	@Transactional
	public Optional<Stock> getByCompanyCodeAndStockExchangeCodeAndStockDateTime(String stockCode, String exchange, LocalDateTime ldt){
		return StockRepos.findByCompanyCodeAndStockExchangeCodeAndStockDateTime(stockCode, exchange, ldt);
	}
	
	@Override
	@Transactional
	public Iterable<Stock> saveAllStockPrice(List<Stock> stockPriceList){
		return StockRepos.saveAll(stockPriceList);
	}
	
	

}
